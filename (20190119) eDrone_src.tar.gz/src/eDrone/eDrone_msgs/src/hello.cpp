

#include <iostream>
#include <mavros_msgs/Waypoint.h>
#include <mavros_msgs/CommandBool.h>
#include <mavros_msgs/CommandTOL.h>
#include <mavros_msgs/CommandLong.h>
using namespace std;

void printHello()
{
	cout << "eDrone_msgs: hello!" << endl; 
}
