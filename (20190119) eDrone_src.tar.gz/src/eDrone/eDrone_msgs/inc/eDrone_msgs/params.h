const double ALTITUDE = 20;

const double STARTING_POS_X_LAT = 20;
const double STARTING_POS_Y_LON = 20;

const double WP_1_X_LAT= 20;
const double WP_1_Y_LON = 120;

const double WP_2_X_LAT = 70;
const double WP_2_Y_LON = 120;

const double WP_3_X_LAT = 70;
const double WP_3_Y_LON = 20;

const double WP_4_X_LAT = 120;
const double WP_4_Y_LON = 20;

const double WP_5_X_LAT = 120;
const double WP_5_Y_LON = 120;




