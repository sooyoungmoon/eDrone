


#include <ros/ros.h>
#include <stdio.h>
#include <stdlib.h>
#include "common_basic_api.h"

/*
namespace Mission_API
{
    //static ros::Rate& rate;

    bool setup(int argc, char** argv, const std::string &name, uint32_t options) // 초기화
    {
        ros::init(argc, argv, name, options);

        printf("setup process\n");
    }

    //// publisher/subscriber

    void publishTopic(Topics topics)
    {
        printf("publishTopic\n");
    }

    void subscribeTopic(Topics topics, int queue_size )
    {
         printf("subscribeTopic\n");
    }

    void subscribeTopic(Topics topics, int queue_size, void* callbackFnPtr )
    {
         printf("subscribeTopic with a custom callback function\n");
    }

     //// service server/client

    void requestService(Services service)
    {
         printf("requestService\n");


         switch (service)
         {
         case arming:

             break;

         case takeoff:

             break;

         case landing:

             break;


         case setMode:
             break;

         default:
             break;

         }
    }

    //// set publishing rate

    /*void setPublishRate (double frequency)
    {
        rate = ros::Rate(frequency);

        printf("publishing rate = %lf \n", frequency);
    }
*/

//// test functions

void Vehicle::helloAPI()
{
    printf("hello API!!\n");

}

//// callback functions

void Vehicle::state_cb(const mavros_msgs::State::ConstPtr& msg){ // 상태 정보 수신에 필요한 콜백 함수
  current_state = *msg;

    if (current_state.connected == true)
  {
       printf("serv_common_mode: state_cb() - UAV connected\n");
  }
  else
  {
       printf("serv_common_mode: state_cb() - UAV not connected\n");
  }
}


void Vehicle::pose_cb(const geometry_msgs::PoseStamped::ConstPtr& msg){ // 자세 정보 수신에 필요한 콜백 함수
      current_location = *msg;
}

/*
bool Vehicle::setup(int argc, char** argv, const std::string &name, uint32_t options) // 초기화
{
    ros::init(argc, argv, name, options);

    printf("setup process\n");

}
*/

bool Vehicle::isConnected() // 연결 상태 점검
{
      printf("check for UAV connection\n");


}

bool Vehicle::arm() // arm
{
      printf("arming\n");

      arm_cmd.request.value = true;

      while (ros::ok() )
        {
              printf("send Arming command ...\n");

              if (!arm_client.call(arm_cmd))
               {
                 ros::spinOnce();
                 rate.sleep();
              }
              else break;
        }

        ROS_ERROR("ARMing command was sent\n");
}

bool Vehicle::takeoff(float altitude) // takeoff
{
      printf("takeoff!\n");

      takeoff_cmd.request.altitude = altitude;

       takeoff_cmd.request.latitude = home_lat; // 자동으로 home position 값을 얻어 와서 설정되도록 변경 필요

       takeoff_cmd.request.longitude = home_lon;

       takeoff_cmd.request.yaw = 0;

       takeoff_cmd.request.min_pitch = 0;


      printf("send Takeoff command ...\n");

      while (ros::ok() )
        {
              printf("send Takeoff command ...\n");

              if (!takeoff_client.call(takeoff_cmd))
              {
                ros::spinOnce();
                rate.sleep();
              }
              else break;
        }
}

bool Vehicle::land() // land (at current location)
{
      printf("landing\n");

      //// Landing

        while (ros::ok() )
        {
              printf("send Landing command ...\n");

              if (!landing_client.call(landing_cmd))
              {
                ros::spinOnce();
                rate.sleep();
              }
              else break;
        }

       ROS_ERROR("Landing command was sent\n");

}

Vehicle::Vehicle()
{
    home_lat = 36.3833699;
    home_lon = 127.3662779;

    arm_client = nh.serviceClient<mavros_msgs::CommandBool> ("mavros/cmd/arming");

    takeoff_client = nh.serviceClient<mavros_msgs::CommandTOL> ("mavros/cmd/takeoff");

    landing_client = nh.serviceClient<mavros_msgs::CommandTOL> ("mavros/cmd/land");

    setMode_client = nh.serviceClient<mavros_msgs::SetMode>("/mavros/set_mode");

    ros::Rate rate(10);
}


} // Mission_API namespace
