

#include <ros/ros.h>
#include <stdio.h>
#include <stdlib.h>
#include <std_msgs/String.h>
#include "geometry_msgs/PoseStamped.h"
#include "geometry_msgs/Vector3Stamped.h"
#include "mavros_msgs/State.h"
#include "mavros_msgs/CommandBool.h"
#include "mavros_msgs/CommandTOL.h"
#include <mavros_msgs/SetMode.h>


/*
namespace Mission_API
{
    bool setup(int argc, char** argv, const std::string &name, uint32_t options=0); // 초기화

    typedef enum _Topics { // MAVROS에서 제공되는 토픽 목록
        state,
        position

    } Topics; //

    typedef enum _Services { // MAVROS에서 제공되는 서비스 목록

        arming,
        takeoff,
        landing,
        setMode
    } Services; //

    //// publisher/subscriber

    void publishTopic(Topics topics);

    void subscribeTopic(Topics topics, int queue_size );

    void subscribeTopic(Topics topics, int queue_size, void* callbackFnPtr );

     //// service server/client

    void requestService(Services service);

    //// set publishing rate

    void setPublishRate (double frequency);
*/

namespace Mission_API
{

class Vehicle

{
  private:  


	
	//// 현재 위치        

        // global position

	double latitude;
	double longitude;
	double altitude;

	// local position 

	double local_x;
	double local_y;
	double local_z;
	
        // home position

        double  home_lat;
        double  home_lon;
	
	// 
       
 	ros::Rate rate;

  public:


  Vehicle();

};

} // namespace Mission_API
